using SME;
namespace sme_example
{
    /// <summary>
    /// The counter control bus
    /// </summary>
    public interface ICounterControl : IBus
    {
        /// <summary>
        /// Set this value to <c>true</c> to reset
        /// </summary>
        [InitialValue(false)] 
        bool Reset { get; set; }

        /// <summary>
        /// Set this value to <c>true</c> to count 1
        /// </summary>
        [InitialValue(false)] 
        bool Valid { get; set; }
    }

    /// <summary>
    /// The counter output bus
    /// </summary>
    public interface ICounterData : IBus
    {
        /// <summary>
        /// The current counter value
        /// </summary>
        [InitialValue(0)] 
        int Value { get; set; }
    }

    /// <summary>
    /// A simple counter process
    /// </summary>    
    public class Counter : SimpleProcess
    {
        /// <summary>
        /// The counter control bus
        /// </summary>
        [InputBus]
        public readonly ICounterControl m_control = Scope.CreateBus<ICounterControl>();

        /// <summary>
        /// The counter data bus
        /// </summary>
        [OutputBus]
        public readonly ICounterData m_data = Scope.CreateBus<ICounterData>();

        /// <summary>
        /// The counter value;
        /// </summary>
        private int m_counter;

        /// <summary>
        /// Handles the progress
        /// </summary>
        protected override void OnTick()
        {
            if (m_control.Reset)
                m_counter = 0;
            else if (m_control.Valid)
                m_counter++;

            m_data.Value = m_counter;
        }
    }
}