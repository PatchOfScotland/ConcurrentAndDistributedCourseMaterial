using System;
using System.Threading.Tasks;
using SME;
namespace sme_example
{
    /// <summary>
    /// The validation class, giving us the result
    /// </summary>
    public class Validator : SimulationProcess
    {
        /// <summary>
        /// The result bus we are reading from
        /// </summary>
        [InputBus]
        public readonly IGraderResult m_result;

        /// <summary>
        /// Creates a new validator process
        /// </summary>
        /// <param name="result">The grader result bus</param>
        public Validator(IGraderResult result)
        {
            m_result = result ?? throw new ArgumentNullException(nameof(result));
        }

        /// <summary>
        /// Runs the simulation process.
        /// Note that this process is not rendered as hardware so we can write to the console
        /// </summary>
        public override async Task Run()
        {
            // image counter
            var image = 0;

            // We do not know how many images we will be grading so we just keep going
            while(true)
            {
                // Wait for a result
                while (!m_result.Valid)
                    await ClockAsync();

                Console.WriteLine($"Grade for image {image++} is: {m_result.Grade}");
                await ClockAsync();
            }
        }

    }
}