using System;
using SME;

namespace sme_example
{
    /// <summary>
    /// The forwaring bus signalling image completion
    /// </summary>
    public interface IClassifierForward : IBus
    {   
        /// <summary>
        /// Flag signaling that the classifier is done
        /// </summary>
        /// <value></value>
        [InitialValue(false)] 
        bool Done { get; set; }
    }

    /// <summary>
    /// The single pixel classifier
    /// </summary>
    public class PixelClasifier : SimpleProcess
    {
        /// <summary>
        /// The camera source we are reading from
        /// </summary>
        [InputBus]
        private readonly ICameraData m_camera;

        /// <summary>
        /// The forward notifier
        /// </summary>
        [OutputBus]
        public readonly IClassifierForward m_forward = Scope.CreateBus<IClassifierForward>();

        /// <summary>
        /// The low counter
        /// </summary>
        [OutputBus]
        private readonly ICounterControl m_counterLow;
        /// <summary>
        /// The medium counter
        /// </summary>
        [OutputBus]
        private readonly ICounterControl m_counterMed;
        /// <summary>
        /// The high counter
        /// </summary>
        [OutputBus]
        private readonly ICounterControl m_counterHigh;

        /// <summary>
        /// A flag keeping track of the process state
        /// </summary>
        private bool m_isActive = false;

        /// <summary>
        /// The low threshold
        /// </summary>
        private const int TH_LOW = 10;
        /// <summary>
        /// The medium threshold
        /// </summary>
        private const int TH_MED = 50;
        /// <summary>
        /// The high threshold
        /// </summary>
        private const int TH_HIGH = 100;

        /// <summary>
        /// Creates a new pixel classifier
        /// </summary>
        /// <param name="camera">The camera bus</param>
        /// <param name="low">The low counter</param>
        /// <param name="med">The medium counter</param>
        /// <param name="high">The hight counter</param>
        public PixelClasifier(ICameraData camera, ICounterControl low, ICounterControl med, ICounterControl high)
        {
            m_camera = camera ?? throw new ArgumentNullException(nameof(camera));
            m_counterLow = low ?? throw new ArgumentNullException(nameof(low)); 
            m_counterMed = med ?? throw new ArgumentNullException(nameof(med));
            m_counterHigh = high ?? throw new ArgumentNullException(nameof(high));
        }

        /// <summary>
        /// Runs the process
        /// </summary>
        protected override void OnTick()
        {
            // Toggle active flag if we are inside an image
            if (!m_isActive && m_camera.Valid)
                m_isActive = true;

            // Assume we are not done
            m_forward.Done = false;

            // Reset if we are not currently inside an image
            m_counterLow.Reset = m_counterMed.Reset = m_counterHigh.Reset = !m_isActive;

            // Check if we are inside an image and the pixel is valid
            if (m_isActive && m_camera.Valid)
            {
                // Compute the pixel intensity
                var i = (m_camera.R * 299u + m_camera.G * 587u + m_camera.B * 144u) / 1000u;

                // Set all counters to no count
                m_counterLow.Valid = m_counterMed.Valid = m_counterHigh.Valid = false;

                // Figure out which, if any, should count
                if (i > TH_HIGH)
                    m_counterHigh.Valid = true;
                else if (i > TH_MED)
                    m_counterMed.Valid = true;
                else if (i > TH_LOW)
                    m_counterLow.Valid = true;

                // If the camera says we are done, send this information forward
                if (m_camera.Done)
                    m_forward.Done = true;
            }
        }
    }
}