using SME;
using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace sme_example
{
    /// <summary>
    /// Camera bus definition
    /// </summary>
    [TopLevelInputBus]
    public interface ICameraData : IBus
    {
        /// <summary>
        /// Flag indicating if the RGB data is valid
        /// </summary>
        [InitialValue(false)] 
        bool Valid { get; set; }
        
        /// <summary>
        /// Flag indicating if the current pixel is the last in the image
        /// </summary>
        /// <value></value>
        [InitialValue(false)] 
        bool Done { get; set; }

        /// <summary>
        /// The red component
        /// </summary>
        byte R { get; set; }
        /// <summary>
        /// The green component
        /// </summary>
        byte G { get; set; }
        /// <summary>
        /// The blue component
        /// </summary>
        byte B { get; set; }
    }

    /// <summary>
    /// Simulates a camera source.
    /// Note that this process is not rendered to hardware,
    /// so we can use any library calls we want
    /// </summary>
    public class CameraSimulator : SimulationProcess
    {
        /// <summary>
        /// The camera bus providing data from the simulated camera
        /// </summary>
        [OutputBus]
        public readonly ICameraData m_camera = Scope.CreateBus<ICameraData>();

        /// <summary>
        /// The list of images to use
        /// </summary>
        private readonly string[] m_images;

        /// <summary>
        /// Creates the camera simulator, emitting the given images
        /// </summary>
        public CameraSimulator(string[] images)
        {
            m_images = images ?? throw new ArgumentNullException(nameof(images));
            if (images.Any(x => string.IsNullOrWhiteSpace(x)))
                throw new ArgumentException("Unexpected empty entry in image list");
            if (images.Length == 0)
                throw new ArgumentException("Unexpected zero length image list");
            var missing = images.FirstOrDefault(x => !File.Exists(x));
            if (missing != null)
                throw new FileNotFoundException($"File not found: {missing}");
        }

        /// <summary>
        /// Runs the simulation process
        /// </summary>
        public override async Task Run()
        {
            // Wait for things to settle
            await ClockAsync();

            // Loop over images
            foreach (var file in m_images)
            {                
                // Get a graphics buffer from each image
                using (var img = Image.FromFile(file))
                using (var bmp = new Bitmap(img, new Size(20, 20)))
                {
                    // Each pixel is now valid
                    m_camera.Valid = true;

                    // Loop over the image pixels
                    for (var i = 0; i < bmp.Height; i++)
                    {
                        for (var j = 0; j < bmp.Width; j++)
                        {
                            var pixel = bmp.GetPixel(j, i);
                            m_camera.R = pixel.R;
                            m_camera.G = pixel.G;
                            m_camera.B = pixel.B;
                            // If we are on the last pixel, emit that
                            m_camera.Done = i == bmp.Height - 1 && j == bmp.Width - 1;

                            await ClockAsync();
                        }
                    }
                }

                m_camera.Valid = false;
                m_camera.Done = false;
                await ClockAsync();
            }
        }        
    }
}