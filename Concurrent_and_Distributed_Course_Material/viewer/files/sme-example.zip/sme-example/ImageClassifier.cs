using SME;
namespace sme_example
{
    /// <summary>
    /// The grader result bus
    /// </summary>
    [TopLevelOutputBus]
    public interface IGraderResult : IBus
    {
        /// <summary>
        /// A flag indicating if the grade result is valid
        /// </summary>
        [InitialValue(false)] 
        bool Valid { get; set; }

        /// <summary>
        /// The grade of the image
        /// </summary>
        byte Grade { get; set; }
    }

    /// <summary>
    /// The image classification process that extracts the counter values
    /// and computes an average for the image
    /// </summary>
    public class ImageClasifier : SimpleProcess
    {
        /// <summary>
        /// The result output bus
        /// </summary>
        [OutputBus]
        public readonly IGraderResult m_result = Scope.CreateBus<IGraderResult>();
        /// <summary>
        /// The forwarder that signals when the counters are ready
        /// </summary>
        [InputBus]
        readonly IClassifierForward m_forward;

        /// <summary>
        /// The low counter data
        /// </summary>
        [InputBus]
        private readonly ICounterData m_counterLow;
        /// <summary>
        /// The medium counter data
        /// </summary>
        [InputBus]
        private readonly ICounterData m_counterMed;
        /// <summary>
        /// The high counter data
        /// </summary>
        [InputBus]
        private readonly ICounterData m_counterHigh;

        /// <summary>
        /// Flag to keep track of the camera state
        /// </summary>
        private bool m_isActive = false;

        /// <summary>
        /// Creates a new image classifier process
        /// </summary>
        /// <param name="forward">The forwarder bus</param>
        /// <param name="low">The low counter</param>
        /// <param name="med">The medium counter</param>
        /// <param name="high">The high counter</param>
        public ImageClasifier(IClassifierForward forward, ICounterData low, ICounterData med, ICounterData high)
        {
            m_forward = forward;
            m_counterLow = low; m_counterMed = med; m_counterHigh = high;
        }

        /// <summary>
        /// Runs the process
        /// </summary>
        protected override void OnTick()
        {
            // Clear the valid flag
            m_result.Valid = false;

            // Only continue if we are done with the image
            if (m_forward.Done)
            {
                // Signal completion
                m_result.Valid = true;
                if (m_counterHigh.Value > 20)
                    m_result.Grade = 2;
                else if (m_counterMed.Value > 20)
                    m_result.Grade = 1;
                else if (m_counterLow.Value > 10)
                    m_result.Grade = 0;
                else
                    m_result.Grade = 3;
            }
        }
    }
}