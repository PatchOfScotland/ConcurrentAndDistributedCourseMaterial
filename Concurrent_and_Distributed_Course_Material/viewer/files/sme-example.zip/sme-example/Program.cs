﻿using System;
using SME;

namespace sme_example
{
    public class Program
    {
        static void Main(string[] args)
        {
            if (args == null || args.Length == 0)
                args = new string[] { "../../image1.jpg", "../../image2.jpg" };

            using (var sim = new Simulation())
            {
                sim
                  .BuildCSVFile()
                  .BuildVHDL();


                // Set up a camera with our images
                var simulator = new CameraSimulator(args);

                // Set up the counters
                var counterLow = new Counter();
                var counterMed = new Counter();
                var counterHigh = new Counter();

                // Wire the classfiers
                var pixelClassifier = new PixelClasifier(simulator.m_camera, counterLow.m_control, counterMed.m_control, counterHigh.m_control);
                var imageClassifier = new ImageClasifier(pixelClassifier.m_forward, counterLow.m_data, counterMed.m_data, counterHigh.m_data);

                // Wire up the validator
                var validator = new Validator(imageClassifier.m_result);

                sim.Run();
            }
        }
    }
}
