from pynq import Overlay
import sys

ol = Overlay('MicDriver_single_z2.bit')
mic = ol.PMODMic_0
ol.download()

while True:
    sys.stdout.write('\r' + str(mic.read()))
