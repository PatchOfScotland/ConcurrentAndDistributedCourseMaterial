from pynq import Overlay
import sys

ol = OverLay('MicEdgeDetector_z2.bit')
order = ol.MicEdgeDetector_0
ol.download()

while True:
    sys.stdout.write('\r' + str(order.read()))
